function myFunction(){const navbar=document.getElementById("myLinks");if(navbar.style.display==="block"){navbar.style.display="none"}else{navbar.style.display="block"}}
const scrollAbout=()=>{var scrollTo=$("body").scrollTop()+$('.about-wrapper').offset().top-100;$('html, body').animate({scrollTop:scrollTo},200)}
const scrollRoadmap=()=>{var scrollTo=$("body").scrollTop()+$('.road-map-header').offset().top-50;$('html, body').animate({scrollTop:scrollTo},200)}
const scrollFAQ=()=>{var scrollTo=$("body").scrollTop()+$('.faq-wrapper').offset().top-50;$('html, body').animate({scrollTop:scrollTo},200)}
const items=document.querySelectorAll(".accordion button");function toggleAccordion(){const itemToggle=this.getAttribute('aria-expanded');for(i=0;i<items.length;i++){items[i].setAttribute('aria-expanded','false')}
if(itemToggle=='false'){this.setAttribute('aria-expanded','true')}}
items.forEach(item=>item.addEventListener('click',toggleAccordion))